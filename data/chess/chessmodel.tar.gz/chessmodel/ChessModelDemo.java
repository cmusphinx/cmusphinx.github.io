/*
 * ChessModelDemo shows how to use the chess language model and the static chess grammar
 *
 * Pre-requisites:
 * 1. Unzip chessmodel.tar.gz into a directory and change "model-dir" below to the directory.
 * 2. Add the paths of your recorded chess game .wav files into WAV_FILES hash map (with a name).
 *
 * Output:
 * 1. xxx_gram.hyp - result for using the static chess grammar
 * 2. xxx_lm.hyp   - result for using the chess language model
 * 3. xxx_cmu.hyp  - result for using the CMU default language model
 */

package edu.cmu.sphinx.demo;

import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.SpeechResult;
import edu.cmu.sphinx.api.StreamSpeechRecognizer;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


public class ChessModelDemo {

    private static final String ACOUSTIC_MODEL =
        "resource:/edu/cmu/sphinx/models/en-us/en-us";
    private static final String DICTIONARY_PATH =
        "resource:/edu/cmu/sphinx/models/en-us/cmudict-en-us.dict";
    private static final String GRAMMAR_PATH =
        "resource:/edu/cmu/sphinx/demo/dialog/";
    private static final String DEFAULT_LANGUAGE_MODEL =
        "resource:/edu/cmu/sphinx/models/en-us/en-us.lm.bin";
    private static final Map<String, String> WAV_FILES = new HashMap<String, String>();

    static {
        //test WAV files
        WAV_FILES.put("game1", "game1-file-path");
        //...
     }

    private static void recognize(Configuration configuration, String wavFile, String hypFile) throws IOException{
        System.out.println("recognize: WAV="+wavFile+" to hyp="+hypFile);
        StreamSpeechRecognizer recognizer = new StreamSpeechRecognizer(configuration);
        recognizer.startRecognition(new FileInputStream(wavFile));
        PrintWriter writer = new PrintWriter(hypFile, "UTF-8");
        SpeechResult result;
        while ((result = recognizer.getResult()) != null) {
            writer.println(result.getHypothesis());
        }
        recognizer.stopRecognition();
        writer.close();
    }

    public static void cmuDefault(String wavFile, String hypFile) throws Exception {
        Configuration configuration = new Configuration();
        configuration.setAcousticModelPath(ACOUSTIC_MODEL);
        configuration.setDictionaryPath(DICTIONARY_PATH);
        configuration.setLanguageModelPath(DEFAULT_LANGUAGE_MODEL);

        recognize(configuration, wavFile, hypFile);
    }

    public static void grammarModel(String wavFile, String hypFile) throws Exception {
        Configuration configuration = new Configuration();
        configuration.setAcousticModelPath(ACOUSTIC_MODEL);
        configuration.setDictionaryPath(DICTIONARY_PATH);
        configuration.setGrammarPath(GRAMMAR_PATH);
        configuration.setUseGrammar(true);
        configuration.setGrammarName("chess");

        recognize(configuration, wavFile, hypFile);
    }

    public static void languageModel(String wavFile, String hypFile) throws Exception {
        Configuration configuration = new Configuration();
        configuration.setAcousticModelPath(ACOUSTIC_MODEL);
        String dicFile = "[model-dir]/1458.dic";
        configuration.setDictionaryPath(dicFile);
        configuration.setGrammarPath(GRAMMAR_PATH);
        configuration.setUseGrammar(false);
        String lmFile = "[model-dir]/1458.lm";
        configuration.setLanguageModelPath(lmFile);

        recognize(configuration, wavFile, hypFile);
    }

    public static void main(String[] args) throws Throwable {
        Set<String> keys = WAV_FILES.keySet();
        for(String key : keys) {
            String wavfile = WAV_FILES.get(key);
            grammarModel(wavfile, key+"_gram.hyp");
            languageModel(wavfile, key+"_lm.hyp");
            cmuDefault(wavfile, key+"_cmu.hyp");
        }
    }
}
